using System.Diagnostics.Eventing.Reader;
using System.Drawing.Text;


namespace ProjetoTelacomBancoV1
{
    public partial class Cadastro : Form
    {int cont = 0;
        public Cadastro()
        {
            InitializeComponent();
        }

        private void bntNovo_Click(object sender, EventArgs e)
        {
            habilitarCampos(); // fun��o criada
            bntNovo.Enabled = false; //desabilitado
            bntSalvar.Enabled = true; //habilitado
            bntCancelar.Enabled = true;
        }
        // Habilitar caixas para preenchimento ao clicar no bot�o Novo. 
        private void habilitarCampos()
        {
            txtNome.Enabled = true;
            txtEmail.Enabled = true;
            txtEscola.Enabled = true;
            txtAnoEscolar.Enabled = true;
            txtTurma.Enabled = true;
        }
        //Desabilitar as caixas de preenchimento
        private void desabilitarCampos()
        {
            txtNome.Enabled = false;
            txtEmail.Enabled = false;
            txtEscola.Enabled = false;
            txtTurma.Enabled = false;
            txtAnoEscolar.Enabled = false;
        }
        private void bntCancelar_Click(object sender, EventArgs e)
        {
            desabilitarCampos();
            limparCampos();
            bntNovo.Enabled = true;
            bntSalvar.Enabled = false;
            bntCancelar.Enabled = false;
        }
        private void limparCampos()
        {
            txtID.Text = string.Empty;
            txtNome.Text = ""; // "" as aspas tem mesmo efeito que string.empty
            txtEmail.Text = string.Empty;
            txtEscola.Text = string.Empty;
            txtAnoEscolar.Text = string.Empty;
            txtTurma.Text = string.Empty;
        }

        private void bntSalvar_Click(object sender, EventArgs e)
        {
            if (validarCampos())
            {
                MessageBox.Show("Salvo com sucesso");
                desabilitarCampos();
                limparCampos();
                bntNovo.Enabled = true;
                bntSalvar.Enabled = false;
                bntCancelar.Enabled = false;
            }
            else
            {
                if (cont == 1)

                    MessageBox.Show("Preencha os campos corretamente." + mensagem);
                else
                    MessageBox.Show("Preencha o campo corretamente." + mensagem);
            }
        }
            string mensagem = string.Empty;

        private bool validarCampos() //bool retorna verdadeiro ou falso
        {
            mensagem = "";
            if (txtNome.Text.Length < 3)
            {
                mensagem += "\nDigite o campo nome.";
                cont++;
            }

            if (txtEmail.Text.Length < 10 || !txtEmail.Text.Contains("@")
            || !txtEmail.Text.Contains("."))
            {
                mensagem += "\nO E-mail deve conter @ e .";
                cont++;
            }

            if (txtEscola.Text.Length > 5)
            {
                mensagem += "\nO nome da escola deve ter no m�nimo 5 caracteres.";
                cont++;
            }

            if (txtAnoEscolar.Text.Length > 1)
            {
                mensagem += "\nDigite o ano escolar.";
                cont++;
            }

            if (txtTurma.Text.Length > 3)
            {
                mensagem += "\nDigite a turma.";
                cont++;
            }
            if (mensagem.Length == 0)

                return true;
            else
                return false;
        }
    }
}