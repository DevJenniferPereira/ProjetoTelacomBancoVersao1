﻿namespace ProjetoTelacomBancoV1
{
    partial class Cadastro
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lbID = new Label();
            txtID = new TextBox();
            txtNome = new TextBox();
            lbNome = new Label();
            txtEmail = new TextBox();
            lbEmail = new Label();
            txtEscola = new TextBox();
            lbEscola = new Label();
            bntNovo = new Button();
            bntSalvar = new Button();
            bntCancelar = new Button();
            txtAnoEscolar = new TextBox();
            lbAnoEscolar = new Label();
            txtTurma = new TextBox();
            lbTurma = new Label();
            SuspendLayout();
            // 
            // lbID
            // 
            lbID.AutoSize = true;
            lbID.Location = new Point(30, 33);
            lbID.Name = "lbID";
            lbID.Size = new Size(18, 15);
            lbID.TabIndex = 0;
            lbID.Text = "ID";
            // 
            // txtID
            // 
            txtID.Enabled = false;
            txtID.Location = new Point(30, 51);
            txtID.Name = "txtID";
            txtID.Size = new Size(100, 23);
            txtID.TabIndex = 1;
            // 
            // txtNome
            // 
            txtNome.Enabled = false;
            txtNome.Location = new Point(30, 108);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(314, 23);
            txtNome.TabIndex = 3;
            // 
            // lbNome
            // 
            lbNome.AutoSize = true;
            lbNome.Location = new Point(30, 90);
            lbNome.Name = "lbNome";
            lbNome.Size = new Size(40, 15);
            lbNome.TabIndex = 2;
            lbNome.Text = "Nome";
            // 
            // txtEmail
            // 
            txtEmail.Enabled = false;
            txtEmail.Location = new Point(30, 167);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(314, 23);
            txtEmail.TabIndex = 5;
            // 
            // lbEmail
            // 
            lbEmail.AutoSize = true;
            lbEmail.Location = new Point(30, 149);
            lbEmail.Name = "lbEmail";
            lbEmail.Size = new Size(41, 15);
            lbEmail.TabIndex = 4;
            lbEmail.Text = "E-mail";
            // 
            // txtEscola
            // 
            txtEscola.Enabled = false;
            txtEscola.Location = new Point(30, 230);
            txtEscola.Name = "txtEscola";
            txtEscola.Size = new Size(314, 23);
            txtEscola.TabIndex = 7;
            // 
            // lbEscola
            // 
            lbEscola.AutoSize = true;
            lbEscola.Location = new Point(30, 212);
            lbEscola.Name = "lbEscola";
            lbEscola.Size = new Size(40, 15);
            lbEscola.TabIndex = 6;
            lbEscola.Text = "Escola";
            // 
            // bntNovo
            // 
            bntNovo.Location = new Point(30, 337);
            bntNovo.Name = "bntNovo";
            bntNovo.Size = new Size(75, 23);
            bntNovo.TabIndex = 8;
            bntNovo.Text = "Novo";
            bntNovo.UseVisualStyleBackColor = true;
            bntNovo.Click += bntNovo_Click;
            // 
            // bntSalvar
            // 
            bntSalvar.Enabled = false;
            bntSalvar.Location = new Point(146, 337);
            bntSalvar.Name = "bntSalvar";
            bntSalvar.Size = new Size(75, 23);
            bntSalvar.TabIndex = 9;
            bntSalvar.Text = "Salvar";
            bntSalvar.UseVisualStyleBackColor = true;
            bntSalvar.Click += bntSalvar_Click;
            // 
            // bntCancelar
            // 
            bntCancelar.Enabled = false;
            bntCancelar.Location = new Point(269, 337);
            bntCancelar.Name = "bntCancelar";
            bntCancelar.Size = new Size(75, 23);
            bntCancelar.TabIndex = 10;
            bntCancelar.Text = "Cancelar";
            bntCancelar.UseVisualStyleBackColor = true;
            bntCancelar.Click += bntCancelar_Click;
            // 
            // txtAnoEscolar
            // 
            txtAnoEscolar.Enabled = false;
            txtAnoEscolar.Location = new Point(30, 283);
            txtAnoEscolar.Name = "txtAnoEscolar";
            txtAnoEscolar.Size = new Size(145, 23);
            txtAnoEscolar.TabIndex = 12;
            // 
            // lbAnoEscolar
            // 
            lbAnoEscolar.AutoSize = true;
            lbAnoEscolar.Location = new Point(30, 265);
            lbAnoEscolar.Name = "lbAnoEscolar";
            lbAnoEscolar.Size = new Size(69, 15);
            lbAnoEscolar.TabIndex = 11;
            lbAnoEscolar.Text = "Ano Escolar";
            // 
            // txtTurma
            // 
            txtTurma.Enabled = false;
            txtTurma.Location = new Point(199, 283);
            txtTurma.Name = "txtTurma";
            txtTurma.Size = new Size(145, 23);
            txtTurma.TabIndex = 14;
            // 
            // lbTurma
            // 
            lbTurma.AutoSize = true;
            lbTurma.Location = new Point(199, 265);
            lbTurma.Name = "lbTurma";
            lbTurma.Size = new Size(41, 15);
            lbTurma.TabIndex = 13;
            lbTurma.Text = "Turma";
            // 
            // Cadastro
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(386, 401);
            Controls.Add(txtTurma);
            Controls.Add(lbTurma);
            Controls.Add(txtAnoEscolar);
            Controls.Add(lbAnoEscolar);
            Controls.Add(bntCancelar);
            Controls.Add(bntSalvar);
            Controls.Add(bntNovo);
            Controls.Add(txtEscola);
            Controls.Add(lbEscola);
            Controls.Add(txtEmail);
            Controls.Add(lbEmail);
            Controls.Add(txtNome);
            Controls.Add(lbNome);
            Controls.Add(txtID);
            Controls.Add(lbID);
            Name = "Cadastro";
            Text = "Cadastro";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lbID;
        private TextBox txtID;
        private TextBox txtNome;
        private Label lbNome;
        private TextBox txtEmail;
        private Label lbEmail;
        private TextBox txtEscola;
        private Label lbEscola;
        private Button bntNovo;
        private Button bntSalvar;
        private Button bntCancelar;
        private TextBox txtAnoEscolar;
        private Label lbAnoEscolar;
        private TextBox txtTurma;
        private Label lbTurma;
    }
}